// const express = require("express");
// const router = express.Router();
// const {
//   createComplaint,
//   getMyComplaints,
//   getAllComplaints,
//   updateComplaintStatus,
//   deleteComplaint,
// } = require("../controller/complaintController");

// const { protect, adminOnly } = require("../middleware/authMiddleware");


// // User Routes
// router.post("/", protect, createComplaint);
// router.get("/my", protect, getMyComplaints);


// // Admin Routes
// router.get("/", protect, adminOnly, getAllComplaints);
// router.put("/:id", protect, adminOnly, updateComplaintStatus);
// router.delete("/:id", protect, adminOnly, deleteComplaint);



// module.exports = router;




const express = require("express");
const router  = express.Router();
const {
  AddContact,
  getAllContacts,
  deleteContact,
} = require("../controller/contactController");
const { protect, adminOnly } = require("../middleware/authMiddleware");

router.post("/add",      AddContact);
router.get("/all",       protect, adminOnly, getAllContacts);
router.delete("/:id",    protect, adminOnly, deleteContact);

module.exports = router;