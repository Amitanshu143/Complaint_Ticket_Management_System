const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const {
  createTicket,
  getMyTickets,
  getAllTickets,
  updateTicket,
  deleteTicket,
} = require("../controllers/ticketController");

// User routes
router.post("/", protect, createTicket);
router.get("/my", protect, getMyTickets);

// Admin routes
router.get("/", protect, getAllTickets);
router.put("/:id", protect, updateTicket);
router.delete("/:id", protect, deleteTicket);

module.exports = router;

