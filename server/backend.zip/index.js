const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const connectDB = require('./config/db');
dotenv.config();

// Connect to the database
connectDB();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());


// Routes
const authRoute = require('./route/authRoute');
const contactRoute = require('./route/contactRoute');
const adminRoute = require("./route/adminRoute");
const complaintRoute =require("./route/complaintRoute")
// Mount Routes
app.use('/api/auth', authRoute);
app.use('/api/contact', contactRoute);
app.use("/api/admin", adminRoute);
app.use("/api/complaints", complaintRoute);

app.get('/', (req, res) => {
  res.send('API is running...');
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});



